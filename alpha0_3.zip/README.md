nm_modern_ellipse is a modification of the Nonogram Modern crosshair by W03L0BED 

This is a modification for World Of Warships version 0.10.3.0

This modification is currently in alpha version 0.2

This modification  adds ellipses to the crosshair that scale by height

To install this modification, copy the gui folder to your res_mods folder, then
 modify your crosshairs.xml to include the following under the <dynamic> section
	
		<crosshair name="Nomogram Modern Ellipse" renderer="NgZlooEllipseRenderer">
			<textures>
				<texture>../crosshairs/ng-z1ooo.png</texture>
		  </textures>
		</crosshair> 

 \- C4Cypher
 
